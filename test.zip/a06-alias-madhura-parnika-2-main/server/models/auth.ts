export type Subject = {
  id: string;
};
